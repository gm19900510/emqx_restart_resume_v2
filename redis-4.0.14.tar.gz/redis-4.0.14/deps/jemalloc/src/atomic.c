#define	JEMALLOC_ATOMIC_C_
#include "jemalloc/internal/jemalloc_internal.h"
